#ifndef _HURO_H_
#define _HURO_H_

#include "../Amazon/Config.h"
#include "HuroMissonConfig.h"

int huro_main(void);
int huro_mission(void);
int huro_continuous_mission(void);

#endif // _HURO_H_
