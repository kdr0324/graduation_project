#ifndef _BARRICADE_H_
#define _BARRICADE_H_

#include "../Amazon/Config.h"

int BarricadeUp(FILE *fp, const char *name);
int BarricadeSide(FILE *fp, const char *name);

#endif // _BARRICADE_H_
