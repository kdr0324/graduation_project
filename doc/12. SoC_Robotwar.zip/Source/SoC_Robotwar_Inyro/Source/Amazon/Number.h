#ifndef _NUMBER_H_
#define _NUMBER_H_

extern unsigned short number[17864];

#endif // _NUMBER_H_
