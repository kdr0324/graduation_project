#ifndef _HIMG_H_
#define _HIMG_H_

extern unsigned short h_lookup[65536];

#endif // _HIMG_H_
