#ifndef _SIMG_H_
#define _SIMG_H_

extern unsigned char s_lookup[65536];

#endif // _SIMG_H_
