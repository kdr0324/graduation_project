#ifndef _IIMG_H_
#define _IIMG_H_

extern unsigned char i_lookup[65536];

#endif // _IIMG_H_
